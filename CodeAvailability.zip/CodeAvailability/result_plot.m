close all;
clear all;
filename = 'result.xlsx';
Lsheetname = 'L';
Rsheetname = 'R';
Ldatatable = readtable(filename, 'sheet', Lsheetname);
Rdatatable = readtable(filename, 'sheet', Rsheetname);
Ldatatable = Ldatatable(1:20,1:19);
Rdatatable = Rdatatable(1:20,1:19);
Ldata=table2array(Ldatatable);
Rdata=table2array(Rdatatable);
date=1:1:size(Ldata,1);

figure;
set(gcf,'unit','normalized','position',[0.1,0.1,0.8,0.3]);
set (gca,'position',[0.1,0.1,0.8,0.8] );
subplot(1,3,1);
LmeanPE=Ldata(:,4);
LerrorPE=Ldata(:,5);
LmeanPF=Ldata(:,6);
LerrorPF=Ldata(:,7);
hold on;
s1=shadedErrorBar(date,LmeanPE,LerrorPE,'patchSaturation',0.1,'lineprops','--');
set(s1.edge,'LineWidth',0.25,'LineStyle','-.');
plot(s1.mainLine.XData, s1.mainLine.YData,'o','MarkerFaceColor','w')
p1 = polyfit(date,LmeanPE,3);
plot(date, polyval(p1, date));
ylim([1200 2800]);
ylabel('Peak Torque (Nmm)');
xlabel('Trial (counts)');
legend(['LeftExtension'],['Flexion'],'','','Average','Location','NorthWest');
legend boxoff;

allChildren = get(gca, 'Children');
displayNames = get(allChildren, 'DisplayName');

legend(allChildren([3]));


subplot(1,3,2);
LmeanAAE=Ldata(:,8);
LerrorAAE=Ldata(:,9);
LmeanAAF=Ldata(:,10);
LerrorAAF=Ldata(:,11);
hold on;
s1=shadedErrorBar(date,LmeanAAE,LerrorAAE,'patchSaturation',0.1,'lineprops','--');
set(s1.edge,'LineWidth',0.25,'LineStyle','-.');
plot(s1.mainLine.XData, s1.mainLine.YData,'o','MarkerFaceColor','w')
p1 = polyfit(date,LmeanAAE,3);
plot(date, polyval(p1, date));
ylim([600 1300])
ylabel('Average Torque (Nmm)');
xlabel('Trial (counts)');
legend(['Extension'],['Flexion'],'','','Average','Location','NorthWest');
legend boxoff;

allChildren = get(gca, 'Children');
displayNames = get(allChildren, 'DisplayName');


legend(allChildren([3]));



subplot(1,3,3);
LmeanWE=Ldata(:,12);
LerrorWE=Ldata(:,13);
LmeanWF=Ldata(:,14);
LerrorWF=Ldata(:,15);
hold on;
s1=shadedErrorBar(date,LmeanWE,LerrorWE,'patchSaturation',0.1,'lineprops','--');
set(s1.edge,'LineWidth',0.25,'LineStyle','-.');
plot(s1.mainLine.XData, s1.mainLine.YData,'o','MarkerFaceColor','w')
p1 = polyfit(date,LmeanWE,3);
plot(date, polyval(p1, date));
ylim([600 1900])
ylabel('Work (Nmm)');
xlabel('Trial (counts)');
legend(['Extension'],['Flexion'],'','','Average','Location','NorthWest');
legend boxoff;

allChildren = get(gca, 'Children');
displayNames = get(allChildren, 'DisplayName');


legend(allChildren([3]));





figure;
set(gcf,'unit','normalized','position',[0.1,0.1,0.8,0.3]);
set (gca,'position',[0.1,0.1,0.8,0.8] );
subplot(1,3,1);
RmeanPE=Rdata(:,4);
RerrorPE=Rdata(:,5);
RmeanPF=Rdata(:,6);
RerrorPF=Rdata(:,7);
hold on;
s1=shadedErrorBar(date,RmeanPE,RerrorPE,'patchSaturation',0.1,'lineprops','--');
set(s1.edge,'LineWidth',0.25,'LineStyle','-.');
plot(s1.mainLine.XData, s1.mainLine.YData,'o','MarkerFaceColor','w')
p1 = polyfit(date,RmeanPE,3);
plot(date, polyval(p1, date));
ylim([1200 2800])
ylabel('Peak Torque (Nmm)');
xlabel('Trial (counts)');
legend(['RightExtension'],['Flexion'],'','','Average','Location','NorthWest');
legend boxoff;

allChildren = get(gca, 'Children');
displayNames = get(allChildren, 'DisplayName');
legend(allChildren([3]));


subplot(1,3,2);
RmeanAAE=Rdata(:,8);
RerrorAAE=Rdata(:,9);
RmeanAAF=Rdata(:,10);
RerrorAAF=Rdata(:,11);
hold on;
s1=shadedErrorBar(date,RmeanAAE,RerrorAAE,'patchSaturation',0.1,'lineprops','--');
set(s1.edge,'LineWidth',0.25,'LineStyle','-.');
plot(s1.mainLine.XData, s1.mainLine.YData,'o','MarkerFaceColor','w')
p1 = polyfit(date,RmeanAAE,3);
plot(date, polyval(p1, date));
ylim([600 1300])
ylabel('Average Torque (Nmm)');
xlabel('Trial (counts)');
legend(['Extension'],['Flexion'],'','','Average','Location','NorthWest');
legend boxoff;

allChildren = get(gca, 'Children');
displayNames = get(allChildren, 'DisplayName');

legend(allChildren([3]));



subplot(1,3,3);
RmeanWE=Rdata(:,12);
RerrorWE=Rdata(:,13);
RmeanWF=Rdata(:,14);
RerrorWF=Rdata(:,15);
hold on;
s1=shadedErrorBar(date,RmeanWE,RerrorWE,'patchSaturation',0.1,'lineprops','--');
set(s1.edge,'LineWidth',0.25,'LineStyle','-.');
plot(s1.mainLine.XData, s1.mainLine.YData,'o','MarkerFaceColor','w')
p1 = polyfit(date,RmeanWE,3);
plot(date, polyval(p1, date));
ylim([600 1900])
ylabel('Work (Nmm)');
xlabel('Trial (counts)');
legend(['Extension'],['Flexion'],'','','Average','Location','NorthWest');
legend boxoff;

allChildren = get(gca, 'Children');
displayNames = get(allChildren, 'DisplayName');

legend(allChildren([3]));



