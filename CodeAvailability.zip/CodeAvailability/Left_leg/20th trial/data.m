clear all;
close all;
clc

dataRange=[700,4200;
    500,4500;
    500,4500;
    500,4500;
    ];
thr=200;
lift=[];
files = dir('*.txt');

range = [1 2 3 4];
for k=1:4
    filename=[num2str(range(k)), '.txt'];
    fid=fopen(filename,'r');
    Rawdata = textscan(fid,'%s ');
    fclose(fid);

    time=0;

    PosiTorque=12;
    PosiSpeed=28;
    PosiAngle=32;
    PosiSet_Speed=40;
    PosiSlider=44;

    for i = 1:length(Rawdata{1,1})
        if(Rawdata{1,1}{i} == 'bb' & Rawdata{1,1}{i+1} == '44')
            time=time+1;

            hextorque(time,:)=[Rawdata{1,1}{i+PosiTorque+3},...
                Rawdata{1,1}{i+PosiTorque+2},...
                Rawdata{1,1}{i+PosiTorque+1},...
                Rawdata{1,1}{i+PosiTorque}];

            hexspeed(time,:)=[Rawdata{1,1}{i+PosiSpeed+3},...
                Rawdata{1,1}{i+PosiSpeed+2},...
                Rawdata{1,1}{i+PosiSpeed+1},...
                Rawdata{1,1}{i+PosiSpeed}];        

            hexangle(time,:)=[Rawdata{1,1}{i+PosiAngle+3},...
                Rawdata{1,1}{i+PosiAngle+2},...
                Rawdata{1,1}{i+PosiAngle+1},...
                Rawdata{1,1}{i+PosiAngle}];

            hexsetspeed(time,:)=[Rawdata{1,1}{i+PosiSet_Speed+3},...
                Rawdata{1,1}{i+PosiSet_Speed+2},...
                Rawdata{1,1}{i+PosiSet_Speed+1},...
                Rawdata{1,1}{i+PosiSet_Speed}];

            hexslider(time,:)=[Rawdata{1,1}{i+PosiSlider+3},...
                Rawdata{1,1}{i+PosiSlider+2},...
                Rawdata{1,1}{i+PosiSlider+1},...
                Rawdata{1,1}{i+PosiSlider}];
        end
    end

    torque = hex2dec(hextorque)-200;
    speed = hex2dec(hexspeed);
    angle = hex2dec(hexangle);
    setspeed = hex2dec(hexsetspeed);
    Slider = hex2dec(hexslider);




    for i=1:length(torque)
        if(torque(i) > 2^32/2-1)
            torque(i) = torque(i) - 2^32;  
        end
    end
    for i=1:length(speed)
        if(speed(i) > 2^32/2-1)
            speed(i) = speed(i) - 2^32;  
        end
    end
    for i=1:length(angle)
        if(angle(i) > 2^32/2-1)
            angle(i) = angle(i) - 2^32;  
        end
    end
    for i=1:length(setspeed)
        if(setspeed(i) > 2^32/2-1)
            setspeed(i) = setspeed(i) - 2^32;  
        end
    end
    Torque = torque(dataRange(range(k),1):dataRange(range(k),2));
    Angle = angle(dataRange(range(k),1):dataRange(range(k),2))/10;
    Speed = speed(dataRange(range(k),1):dataRange(range(k),2));
    Time = 0:0.01:(dataRange(range(k),2)-dataRange(range(k),1))*0.01;
    
    angleRange=360;
    torqueRange=4000;

    for i=1:length(Torque)
            if(abs(Torque(i))>torqueRange)
                Torque(i)=Torque(i-1);
            end
     end
     for i=1:length(Angle)
        if(abs(Angle(i))>angleRange)
            Angle(i)=Angle(i+1);
        end
     end
     for i=1:length(Angle)
        if(abs(Angle(i))>angleRange)
            Angle(i)=Angle(i+1);
        end
      end
     for i=1:length(Speed)
        if(Speed(i)<-100)
            Speed(i)=Speed(i-1);
        end
      end


    temp=0;
    for i=1:length(Speed)-1
        if(Speed(i+1)*Speed(i)<=0)
            temp=temp+1;
            zeroSpeed(temp)=i;
        end
    end
    AngleMin=find(diff(sign(diff(Angle)))>0)+1;   
    AngleMax=find(diff(sign(diff(Angle)))<0)+1;
    
    
   

    posiError=[];
    count=0;
    for i=1:length(AngleMin)
        if(Angle(AngleMin(i))>=mean(Angle))
            AngleMin(i)=0;
            count=count+1;
            posiError(count)=i;
        end
    end
    for i=1:length(posiError)
        AngleMin(posiError(i))=[];
        posiError=posiError-1;
    end

    posiError=[];
    count=0;
    for i=1:length(AngleMax)
        if(Angle(AngleMax(i))<=mean(Angle))
            AngleMax(i)=0;
            count=count+1;
            posiError(count)=i;
        end
    end
    for i=1:length(posiError)
        AngleMax(posiError(i))=[];
        posiError=posiError-1;
    end

   
    posiError=[];
    count=0;
    for i=1:length(AngleMin)-1
        if(abs(AngleMin(i+1)-AngleMin(i))<thr)
            count=count+1;
            if(Angle(AngleMin(i+1))<=Angle(AngleMin(i)))
                posiError(count)=i;
            else posiError(count)=i+1;
            end
        end
    end
    for i=1:length(posiError)
        AngleMin(posiError(i))=[];
        posiError=posiError-1;
    end


    posiError=[];
    count=0;
    for i=1:length(AngleMax)-1
        if(abs(AngleMax(i+1)-AngleMax(i))<thr)
            count=count+1;
            if(Angle(AngleMax(i+1))>=Angle(AngleMax(i)))
                posiError(count)=i;   
            else posiError(count)=i+1;
            end
        end
    end
    for i=1:length(posiError)
        AngleMax(posiError(i))=[];
        posiError=posiError-1;
    end

  
    
    figure;

    subplot(3,1,1)
    hold on
    plot(Time,Speed,'color',[0.3,0.7,0.2]);
    ylabel('Velocity (°/s)');
    subplot(3,1,2)
    hold on
    plot(Time,Angle)
    ylabel('Angle (°)');
    scatter(AngleMax/100,Angle(AngleMax),'filled','MarkerFaceAlpha',.5,'MarkerEdgeAlpha',.5)
    scatter(AngleMin/100,Angle(AngleMin),'filled','MarkerFaceAlpha',.5,'MarkerEdgeAlpha',.5)



    subplot(3,1,3)
    hold on
    plot(Time,Torque);
    ylabel('Torque (Nmm)');
    
    TorqueMax=[];
    TorqueMin=[];
    if(length(AngleMin)<length(AngleMax))
        for i=1:min(length(AngleMin),length(AngleMax))
            segTF=Torque(AngleMin(i):AngleMax(i+1));
            segAF=Angle(AngleMin(i):AngleMax(i+1))/57.3;
            workF(i)=trapz(segAF,segTF);
            [p(i),q]=max(segTF);
            TorqueMax(i)=q+AngleMin(i)-1;
            meanF(i,1)=mean(segTF);
        end
        for i=1:min(length(AngleMin),length(AngleMax))
            segTE=Torque(AngleMax(i):AngleMin(i));
            x = 0:1/300:1;
            x1 = 0:1/(size(segTE,1)-1):1;
            y1 = interp1(x1,segTE',x,'spline');
            lift=[lift y1'];
            segAE=Angle(AngleMax(i):AngleMin(i))/57.3;
            workE(i)=trapz(segAE,segTE);
            [p(i),q]=min(segTE);
            TorqueMin(i)=q+AngleMax(i)-1;
            meanE(i,1)=mean(segTE);
        end
    elseif(length(AngleMin)>length(AngleMax))
        for i=1:min(length(AngleMin),length(AngleMax))
            segTF=Torque(AngleMin(i):AngleMax(i));
            segAF=Angle(AngleMin(i):AngleMax(i))/57.3;
            workF(i)=trapz(segAF,segTF);
            [p(i),q]=max(segTF);
            TorqueMax(i)=q+AngleMin(i)-1;
            meanF(i,1)=mean(segTF);
        end
        for i=1:min(length(AngleMin),length(AngleMax))
            segTE=Torque(AngleMax(i):AngleMin(i+1));
            x = 0:1/300:1;
            x1 = 0:1/(size(segTE,1)-1):1;
            y1 = interp1(x1,segTE',x,'spline');
            lift=[lift y1'];
            segAE=Angle(AngleMax(i):AngleMin(i+1))/57.3;
            workE(i)=trapz(segAE,segTE);
            [p(i),q]=min(segTE);
            TorqueMin(i)=q+AngleMax(i)-1;
            meanE(i,1)=mean(segTE);
        end
    elseif(AngleMin(1)<=AngleMax(1)) 
        for i=1:length(AngleMin)
            segTF=Torque(AngleMin(i):AngleMax(i));
            segAF=Angle(AngleMin(i):AngleMax(i))/57.3;
            workF(i)=trapz(segAF,segTF);
            [p(i),q]=max(segTF);
            TorqueMax(i)=q+AngleMin(i)-1;
            meanF(i,1)=mean(segTF);
        end
        for i=1:length(AngleMin)-1
            segTE=Torque(AngleMax(i):AngleMin(i+1));
            x = 0:1/300:1;
            x1 = 0:1/(size(segTE,1)-1):1;
            y1 = interp1(x1,segTE',x,'spline');
            lift=[lift y1'];
            segAE=Angle(AngleMax(i):AngleMin(i+1))/57.3;
            workE(i)=trapz(segAE,segTE);
            [p(i),q]=min(segTE);
            TorqueMin(i)=q+AngleMax(i)-1;
            meanE(i,1)=mean(segTE);
        end
    else
        for i=1:length(AngleMin)-1
            segTF=Torque(AngleMin(i):AngleMax(i+1));
            segAF=Angle(AngleMin(i):AngleMax(i+1))/57.3;
            workF(i)=trapz(segAF,segTF);
            [p(i),q]=max(segTF);
            TorqueMax(i)=q+AngleMin(i)-1;
            meanF(i,1)=mean(segTF);
        end
        for i=1:length(AngleMin)
            segTE=Torque(AngleMax(i):AngleMin(i));
            x = 0:1/300:1;
            x1 = 0:1/(size(segTE,1)-1):1;
            y1 = interp1(x1,segTE',x,'spline');
            lift=[lift y1'];
            segAE=Angle(AngleMax(i):AngleMin(i))/57.3;
            workE(i)=trapz(segAE,segTE);
            [p(i),q]=min(segTE);
            TorqueMin(i)=q+AngleMax(i)-1;
            meanE(i,1)=mean(segTE);
        end
    end

        scatter(TorqueMax/100,Torque(TorqueMax),'filled','MarkerFaceAlpha',.5,'MarkerEdgeAlpha',.5)
        scatter(TorqueMin/100,Torque(TorqueMin),'filled','MarkerFaceAlpha',.5,'MarkerEdgeAlpha',.5)

        peakE=Torque(TorqueMin);
        peakF=Torque(TorqueMax);
        
        j=1;
        torloc=[];
        for i=1:length(Speed)
            if Speed(i)<0
                torloc(j)=i;
                j=j+1;
            end
        end
        
        
        meanAngleMax(k)=mean(Angle(AngleMax));
        meanAngleMin(k)=mean(Angle(AngleMin));
        meanAngle(1,k)=100 - meanAngleMin(k);
        peakAE(1,k)=mean(peakE);
        peakAF(1,k)=mean(peakF);
        meanAE(1,k)=mean(Torque(torloc));
        meanAF(1,k)=mean(meanF);
        workAE(1,k)=mean(workE);
        workAF(1,k)=mean(workF);
        MaxTE(1,k)=max(-peakE);
        MaxTF(1,k)=max(peakF);
        MaxAng(1,k)=max(Angle(AngleMax));
        MinAng(1,k)=min(Angle(AngleMin));
        
        
end


meanA=mean(meanAngle);
errorA=std(meanAngle);

meanPE=mean(-peakAE);
errorPE=std(-peakAE);
meanPF=mean(peakAF);
errorPF=std(peakAF);

meanAAE=mean(-meanAE);
errorAAE=std(-meanAE);
meanAAF=mean(meanAF);
errorAAF=std(meanAF);

meanWE=mean(workAE);
errorWE=std(workAE);
meanWF=mean(workAF);
errorWF=std(workAF);

MaxE=max(MaxTE);
MaxF=max(MaxTF);

MaxA=max(MaxAng);
MinA=min(MinAng);

putcat = cat(2,meanA,errorA,meanPE,errorPE,meanPF,errorPF,meanAAE,errorAAE,meanAAF,errorAAF,meanWE,errorWE,meanWF,errorWF,MaxE,MaxF,MaxA,MinA);
putcat=roundn(putcat,-2)

figure;
lift=-lift/1000;
x = x*100;
plot(x,lift);
hold on;
xticks([0 50 100]);
xtickformat('percentage');
ylim([0,3]);
yticks([0 1.50 3.00]);
set(gca,'Box','off');
figure;
row_mean = mean(lift,2);
row_std = std(lift,0,2);
shadedErrorBar(x,row_mean,row_std); 
xticks([0 50 100]);
xtickformat('percentage');
ylim([0,3.0]);
yticks([0 1.50 3.00]);
ylabel('Nm');
hold on
[max_value,max_index] = max(row_mean);
plot(x(max_index),max_value,'o');
text(x(max_index),max_value+100,num2str(max_value));